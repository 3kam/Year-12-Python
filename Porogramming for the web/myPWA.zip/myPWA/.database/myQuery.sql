--CREATE TABLE extension(extID INTERGER NOT NULL PRIMARY KEY,name TEXT NOT NULL, hyperlink TEXT NOT NULL,about TEXT NOT NULL,image TEXT NOT NULL,language TEXT NOT NULL);

-- INSERT INTO extension(extID,name,hyperlink,about,image,language) VALUES (1,'Live Server','https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer','Launch a development local Server with live reload feature for static & dynamic pages','https://ritwickdey.gallerycdn.vsassets.io/extensions/ritwickdey/liveserver/5.7.9/1661914858952/Microsoft.VisualStudio.Services.Icons.Default','HTML CSS JS');

SELECT * FROM extension;

SELECT * FROM extension WHERE language LIKE '#BASH';
